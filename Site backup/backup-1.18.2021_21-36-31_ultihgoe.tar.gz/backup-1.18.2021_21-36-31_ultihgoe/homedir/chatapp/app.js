const express=require('express');
const http=require('http');
const app=express();
const server=http.createServer(app);
const io=require('socket.io')(server);
var roomid=undefined;

app.use(express.urlencoded({extended:"false"}));
app.use(express.json());

app.get('/',(req,res)=>{
    res.sendFile(__dirname+'/landingpage.html');
});
app.get('/landingpage.css', (req,res)=>{
    res.sendFile(__dirname +'/landingpage.css');
});
app.get('/main',(req,res)=>{
    res.sendFile(__dirname+'/landingpage.html');
});
app.post('/main',(req,res)=>{
    roomid=req.body.room_id;
    if(roomid){
        res.sendFile(__dirname+'/index.html');
        console.log(req.body.room_id);
    }
    else{
        res.sendFile(__dirname+'/landingpage.html');
    }
});

io.on('connection',(socket)=>{
        console.log('a user connected');
        socket.join(roomid);
        socket.on('chat message',(msg)=>{
            io.to(Array.from(socket.rooms.keys())[1]).emit('chat message',msg);
            console.log('msg : '+msg);
        });
        socket.on('disconnect',()=>{
            console.log('user disconnected');
        });
});

server.listen(3000,()=>{
    console.log("Listning at port 3000");
});